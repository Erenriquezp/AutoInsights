# placeholder package for offline Terraform tests
